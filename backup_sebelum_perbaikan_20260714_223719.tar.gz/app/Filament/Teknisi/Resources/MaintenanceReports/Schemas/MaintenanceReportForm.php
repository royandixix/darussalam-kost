<?php

namespace App\Filament\Teknisi\Resources\MaintenanceReports\Schemas;

use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Schemas\Schema;

class MaintenanceReportForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Select::make('user_id')
                    ->label('Nama Penghuni')
                    ->relationship('user', 'name')
                    ->disabled(),

                Select::make('room_id')
                    ->label('Kamar')
                    ->relationship('room', 'room_number')
                    ->disabled(),

                TextInput::make('title')
                    ->label('Judul Kerusakan')
                    ->disabled(),

                Textarea::make('description')
                    ->label('Deskripsi Kerusakan')
                    ->disabled()
                    ->rows(4)
                    ->columnSpanFull(),

                FileUpload::make('photo')
                    ->label('Foto Kerusakan')
                    ->image()
                    ->disk('public')
                    ->directory('maintenance-reports')
                    ->visibility('public')
                    ->disabled(),

                Select::make('priority')
                    ->label('Prioritas')
                    ->options([
                        'low' => 'Rendah',
                        'medium' => 'Sedang',
                        'high' => 'Tinggi',
                    ])
                    ->disabled(),

                Select::make('status')
                    ->label('Status Pengerjaan')
                    ->options([
                        'assigned' => 'Ditugaskan',
                        'in_progress' => 'Sedang Dikerjakan',
                        'completed' => 'Selesai',
                    ])
                    ->required(),

                Textarea::make('technician_note')
                    ->label('Catatan Teknisi')
                    ->placeholder('Contoh: Area kamar sudah dicek, ditemukan banyak sarang laba-laba dan akan dilakukan pembersihan.')
                    ->rows(4)
                    ->dehydrated(false)
                    ->columnSpanFull(),
            ]);
    }
}